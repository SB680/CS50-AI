import csv
import itertools
import sys
import copy 
PROBS = {

    # Unconditional probabilities for having gene
    "gene": {
        2: 0.01,
        1: 0.03,
        0: 0.96
    },

    "trait": {

        # Probability of trait given two copies of gene
        2: {
            True: 0.65,
            False: 0.35
        },

        # Probability of trait given one copy of gene
        1: {
            True: 0.56,
            False: 0.44
        },

        # Probability of trait given no gene
        0: {
            True: 0.01,
            False: 0.99
        }
    },

    # Mutation probability
    "mutation": 0.01
}


def main():

    # Check for proper usage
    sys.argv = ['family0']
    #if len(sys.argv) != 2: --useless line of code 
    #    sys.exit("Usage: python heredity.py data.csv")
    people = load_data(sys.argv[0])

    # Keep track of gene and trait probabilities for each person
    probabilities = {
        person: {
            "gene": {
                2: 0,
                1: 0,
                0: 0
            },
            "trait": {
                True: 0,
                False: 0
            }
        }
        for person in people
    }
    
    copied = copy.deepcopy(probabilities) 
    # Loop over all sets of people who might have the trait
    names = set(people)
    for have_trait in powerset(names):

        # Check if current set of people violates known information
        fails_evidence = any(
            (people[person]["trait"] is not None and
             people[person]["trait"] != (person in have_trait))
            for person in names
        )
        if fails_evidence:
            continue

        # Loop over all sets of people who might have the gene 
        
        for one_gene in powerset(names):
            for two_genes in powerset(names - one_gene):

                # Update probabilities with new joint probability
                #print("people: ",people); print("one_gene: ",one_gene); print("two_genes: ",two_genes); print("have_trait: ",have_trait)
                p = joint_probability2(people, one_gene, two_genes, have_trait) 
                #print("p: ",p)
                #print("p2: ",joint_probability2(people, one_gene, two_genes, have_trait))
                update(probabilities, one_gene, two_genes, have_trait, p)
                #print("USING OFF: ",probabilities)
                p2 = joint_probability2(people, one_gene, two_genes, have_trait)
                update(copied, one_gene, two_genes, have_trait, p2)
##                if not round(p,5)==round(p2,5):
##                    print("people= ",people); print("one_gene= ",one_gene); print("two_genes= ",two_genes); print("have_trait= ",have_trait)
##                    print("ERROR P NOT P2")
##                    print("p: ",p)
##                    print("p2: ",p2) 
                #print("USING UNOFF: ",copied)
    # Ensure probabilities sum to 1
    normalize(probabilities)
    normalize(copied) 
    #b1 = normalize(probabilities)
    #print("NORM USING OFF: ",probabilities) 
    #b2 = normalize(copied)
    #print("NORM USING UNOFF: ",copied)
    # Print results
    for person in people:
        #print(f"{person}:")
        for field in probabilities[person]:
            print(f"  {field.capitalize()}:")
            for value in probabilities[person][field]:
                p = probabilities[person][field][value]
                print(f"    {value}: {p:.4f}")

def load_data(filename):
    """
    Load data from CSV files into memory.
    """
    data = dict()
    #HOW TO USE: {} INDICATE A VARIABLE -- IE YOU CAN'T WRITE {data}; you could write family0 but not {family0}; or {filename} not filename  
    with open(f"data/{filename}.csv") as f:
        reader = csv.DictReader(f) 
        for row in reader:
            name = row["name"]
            data[name] = {
                "name": name,
                "mother": row["mother"] or None,
                "father": row["father"] or None,
                "trait": (True if row["trait"] == "1" else
                          False if row["trait"] == "0" else None)
            }
    print ("DATA: ",data) 
    return data
        
        
def powerset(s):
    """
    Return a list of all possible subsets of set s.
    """
    s = list(s)
    return [
        set(s) for s in itertools.chain.from_iterable(
            itertools.combinations(s, r) for r in range(len(s) + 1)
        )
    ]

def probability_inheritence(num_genes_of_parent, is_inherited):
    """
    Given the number of copies of the gene the parent has (0, 1 or 2), 
    and the inheritence outcome (True if child inherits gene from this parent, else False),
    computes the probability of the inheritance outcome for this parent.
    """
    # If parent has no copy of gene, can only pass it on via mutation
    if num_genes_of_parent == 0:
        if is_inherited:
            return PROBS["mutation"]
        else:
            return 1 - PROBS["mutation"]

    # If parent has 1 copy of gene, 50/50 chance of whether they pass it on
    elif num_genes_of_parent == 1:
        return 0.5
    
    # If parent has 2 copies of gene, only way they won't pass it on is via mutation
    elif num_genes_of_parent == 2:
        if is_inherited:
            return 1 - PROBS["mutation"]
        else:
            return PROBS["mutation"]
    
    else:
        raise Exception("invalid input")


def num_genes_of_person(person, one_gene, two_genes):
    """
    Helper function for joint_probability
    """
    if person in one_gene:
        return 1
    elif person in two_genes:
        return 2
    else:
        return 0


def joint_probability(people, one_gene, two_genes, have_trait):
    """
    Compute and return a joint probability.
    The probability returned should be the probability that
        * everyone in set `one_gene` has one copy of the gene, and
        * everyone in set `two_genes` has two copies of the gene, and
        * everyone not in `one_gene` or `two_gene` does not have the gene, and
        * everyone in set `have_trait` has the trait, and
        * everyone not in set` have_trait` does not have the trait.
    """
    # Initialise joint probability
    probability = 1

    for person in people:

        # Want to calculate probability that person has num_genes
        num_genes = num_genes_of_person(person, one_gene, two_genes)

        # Want to calculate probability that person has_trait
        has_trait = person in have_trait

        # No parental information - use unconditional probability
        if people[person]['mother'] is None and people[person]['father'] is None:
            probability *= PROBS["gene"][num_genes] * PROBS["trait"][num_genes][has_trait]

        # Parental information provided - use conditional probability
        else:
            num_genes_mother = num_genes_of_person(people[person]['mother'], one_gene, two_genes)
            num_genes_father = num_genes_of_person(people[person]['father'], one_gene, two_genes)

            # Only 1 way to inherit 0 copies: inherit 0 copies from each parent
            if num_genes == 0:
                probability *= probability_inheritence(num_genes_mother, False) * probability_inheritence(num_genes_father, False)
            
            # Two ways to inherit 1 copy: 1 from mother and 0 from father, or vice versa
            elif num_genes == 1:
                probability *= probability_inheritence(num_genes_mother, True) * probability_inheritence(num_genes_father, False) \
                                + probability_inheritence(num_genes_mother, False) * probability_inheritence(num_genes_father, True)
            
            # Only 1 way to inherit 2 copies: inherit 1 copy from each parent
            elif num_genes == 2:
                probability *= probability_inheritence(num_genes_mother, True) * probability_inheritence(num_genes_father, True)

            # Multiply by probability of having the trait
            probability *= PROBS["trait"][num_genes][has_trait]

    return probability

def joint_probability2(people, one_gene, two_genes, have_trait): 
    """
    Compute and return a joint probability.

    The probability returned should be the probability that
        * everyone in set `one_gene` has one copy of the gene, and
        * everyone in set `two_genes` has two copies of the gene, and
        * everyone not in `one_gene` or `two_gene` does not have the gene, and
        * everyone in set `have_trait` has the trait, and
        * everyone not in set` have_trait` does not have the trait.
    """
    #print("JOINT PROB USNG THESE VALS: ") 
    #print ("PEOPLE: ",people); print ("one_gene: ",one_gene); print ("two_genes: ",two_genes); print ("have_trait: ",have_trait); 
    prob = 1   
    prob0 = PROBS["gene"][0]; prob1 = PROBS["gene"][1]; prob2 = PROBS["gene"][2]; #prob0: p(has 0 gene) 

    probtraitgiven0 = PROBS['trait'][0][True]; probtraitgiven1 = PROBS['trait'][1][True]; probtraitgiven2 = PROBS['trait'][2][True];
    pxgene = [prob0,prob1,prob2]
    ptraitgivenxgene = [probtraitgiven0,probtraitgiven1,probtraitgiven2]
    #pgetsxgenegivenparenthas
    for person in people:
        #trait = people[person]['trait'] #does the person have the trait? THIS IS WRONG SINCE IF 'NONE' THEN WE DON'T KNOW -- THAT'S DOESN'T MEAN THEY
        #AREN'T IN HAVETRAIT; NONE APPLIES TO THE CHILD -- WHO MAY OR MAY NOT GET THE TRAIT AND WE WANT TO FIND THE CHANCE THEY DO OR DON'T
        #DEPENDING ON WHETHER THEY ARE HAVE_TRAIT 
        trait = person in have_trait 
        if trait == None:
            trait = False 
        if not people[person]['mother'] == None: 
            motherhastrait = people[people[person]['mother']]['trait'] #means she has 0 bad genes 
            fatherhastrait = people[people[person]['father']]['trait'] #2 bad genes
 
            mother = people[person]['mother']; father = people[person]['father'];

            pgetsifparenthas1 = 0.5; pgetsifparenthas0 = 0.01; pgetsifparenthas2 = 0.99;  #pgetsif1 = 0.5*(0.01 + 0.99) 
            pgetsifparenthasx = [pgetsifparenthas0,pgetsifparenthas1,pgetsifparenthas2]
            numdeffathergene =2*(father in two_genes) + int(father in one_gene); numdefmothergene =2*(mother in two_genes) + int(mother in one_gene);
            
            pgetsfromfather = pgetsifparenthasx[numdeffathergene];  
            pgetsfrommother = pgetsifparenthasx[numdefmothergene]; 
            
            pperson1 = pgetsfrommother*(1-pgetsfromfather) + pgetsfromfather*(1-pgetsfrommother) #p(person has 1 of the bad gene) 
            pperson0 =(1-pgetsfromfather)*(1-pgetsfrommother) 
            pperson2 = pgetsfrommother*pgetsfromfather
            #print("pperson1: ",pperson1)
            
            if person in one_gene:
                #print("probtraitgiven1: ",probtraitgiven1) 
                prob*= pperson1*(1-probtraitgiven1)*(not trait) + pperson1*(probtraitgiven1)*trait
                #print("trait: ",trait)
##                print("probtraitgiven1: ",probtraitgiven1)
##                print("pperson1: ",pperson1)
##                print("prob: ",prob) 
            elif person in two_genes: 
                prob*= pperson2*(1-probtraitgiven2)*(not trait) + pperson2*(probtraitgiven2)*trait
            else: 
                prob*= pperson0*(1-probtraitgiven0)*(not trait) + pperson0*(probtraitgiven0)*trait
            #print("prob: ",prob)   
        else:
            numgens = 2*(person in two_genes) + int(person in one_gene);
            #print("numgen: " ,numgens) 
            if not trait: #then find p(not have trait)
                prob*=pxgene[numgens]*(1-ptraitgivenxgene[numgens]) #probtraitgiven0: probability they have the trait (are in have_trait) with 0 genes -- that of a mutation
##                print("pxgene[numgens]: ",pxgene[numgens])
##                print("(1-ptraitgivenxgene[numgens]): ",(1-ptraitgivenxgene[numgens]))
##                print("probif1: ",prob)
            elif trait: #then find p(have trait given 2 genes)  
                prob*=pxgene[numgens]*(ptraitgivenxgene[numgens])
##                print("pxgene[numgens]: ",pxgene[numgens])
##                print("(ptraitgivenxgene[numgens]): ",(ptraitgivenxgene[numgens]))
##                print("probif2: ",prob)
    return prob

def update(probabilities, one_gene, two_genes, have_trait, p):
    """
    Add to `probabilities` a new joint probability `p`.
    Each person should have their "gene" and "trait" distributions updated.
    Which value for each distribution is updated depends on whether
    the person is in `have_gene` and `have_trait`, respectively.
    """

    for person in probabilities:
        num = 2 *(person in two_genes) + (person in one_gene); 
        probabilities[person]["gene"][num]+=p
        trait = person in have_trait 
        probabilities[person]['trait'][trait]+=p 

def normalize(probabilities):
    """
    Update `probabilities` such that each probability distribution
    is normalized (i.e., sums to 1, with relative proportions the same).
    """ 
    print( "TESTING NORMALIZE USING THIS DICT: ",probabilities) 

    for person in probabilities.keys():
        s = 0; y = 0 
        for numgen in probabilities[person]['gene']:
            s+=probabilities[person]['gene'][numgen]
        for numgen in probabilities[person]['gene']:
            probabilities[person]['gene'][numgen]*=1/s
        for val in probabilities[person]['trait']:
            y+=probabilities[person]['trait'][val]
        for val in probabilities[person]['trait']:
            probabilities[person]['trait'][val]*=1/y 
          

people = {
'Harry': {'name': 'Harry', 'mother': 'Lily', 'father': 'James', 'trait': None},
'James': {'name': 'James', 'mother': None, 'father': None, 'trait': True},
'Lily': {'name': 'Lily', 'mother': None, 'father': None, 'trait': False}
}
one_gene ={"Harry"}; two_genes = {"James"}; have_trait = {"James"}


print("TESTING JOINT PROBS: ") 

print (joint_probability(people, one_gene, two_genes, have_trait))

probabilities = {'Harry': {'gene': {2: 0, 1: 0, 0: 0}, 'trait': {True: 0, False: 0}},
        'James': {'gene': {2: 0, 1: 0, 0: 0}, 'trait': {True: 0, False: 0}}, 'Lily': {'gene': {2: 0, 1: 0, 0: 0}, 'trait': {True: 0, False: 0}}}
p = 0.00266; 
print("TESTING UPDATE: ") 

print(update(probabilities, one_gene, two_genes, have_trait, p)) 

print(probabilities) 

print ("TESTING NORMALIZE")
print("UPDATED DICTIONARY") 
print(normalize(probabilities))
print("END OF TESTS ") 

print("SECOND TEST: ")

##people=  {'Harry': {'name': 'Harry', 'mother': 'Lily', 'father': 'James', 'trait': None}, 'James': {'name': 'James',
##            'mother': None, 'father': None, 'trait': True}, 'Lily': {'name': 'Lily', 'mother': None, 'father': None, 'trait': False}}
##one_gene=  {'Harry'}
##two_genes=  set()
##have_trait=  {'James'}

people=  {'Harry': {'name': 'Harry', 'mother': 'Lily', 'father': 'James', 'trait': None}, 'James': {'name': 'James', 'mother': None, 'father': None,
                        'trait': True}, 'Lily': {'name': 'Lily', 'mother': None, 'father': None, 'trait': False}}
one_gene=  {'Harry', 'James', 'Lily'}
two_genes=  set()
have_trait=  {'Harry', 'James'}
print("CORRECT VALUE: ",joint_probability(people, one_gene, two_genes, have_trait)) 
print (joint_probability2(people, one_gene, two_genes, have_trait))

#p = p(james has trait given 2 genes)*p(2 genes) * p(lily doesn't have trait given 0 genes)*p(0 genes)*p(harry has 0 genes)*p(harry doesn't have trait given 0 genes)  

#p(harry has 0 genes) = 0.0099


if __name__ == "__main__":
    main()
